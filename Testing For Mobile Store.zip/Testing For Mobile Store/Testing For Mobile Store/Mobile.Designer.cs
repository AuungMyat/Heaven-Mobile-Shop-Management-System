﻿namespace Testing_For_Mobile_Store
{
    partial class Mobile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.MobileIDTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.MobiBrandTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.MobiModeleTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.MobiPriceTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.MobiStockTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.ramcb = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.romcb = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.CamTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.MAddbtn = new Guna.UI2.WinForms.Guna2Button();
            this.MobileUpdatebtn = new Guna.UI2.WinForms.Guna2Button();
            this.MobileDeletebtn = new Guna.UI2.WinForms.Guna2Button();
            this.MobileClearbtn = new Guna.UI2.WinForms.Guna2Button();
            this.MobileDGV = new Guna.UI2.WinForms.Guna2DataGridView();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.BackMBbtn = new Guna.UI2.WinForms.Guna2Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MobileDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(309, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(342, 28);
            this.label1.TabIndex = 3;
            this.label1.Text = "Heaven Mobile Management System";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(373, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(211, 28);
            this.label2.TabIndex = 4;
            this.label2.Text = "Manage Mobile Stock";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(49, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 28);
            this.label3.TabIndex = 8;
            this.label3.Text = "ID";
            // 
            // MobileIDTb
            // 
            this.MobileIDTb.BackColor = System.Drawing.Color.Gainsboro;
            this.MobileIDTb.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.MobileIDTb.CustomizableEdges = customizableEdges1;
            this.MobileIDTb.DefaultText = "";
            this.MobileIDTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.MobileIDTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.MobileIDTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.MobileIDTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.MobileIDTb.FillColor = System.Drawing.Color.WhiteSmoke;
            this.MobileIDTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.MobileIDTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MobileIDTb.ForeColor = System.Drawing.Color.Black;
            this.MobileIDTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.MobileIDTb.Location = new System.Drawing.Point(160, 109);
            this.MobileIDTb.Name = "MobileIDTb";
            this.MobileIDTb.PasswordChar = '\0';
            this.MobileIDTb.PlaceholderText = "Enter ID";
            this.MobileIDTb.SelectedText = "";
            this.MobileIDTb.ShadowDecoration.CustomizableEdges = customizableEdges2;
            this.MobileIDTb.Size = new System.Drawing.Size(111, 38);
            this.MobileIDTb.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(49, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 28);
            this.label4.TabIndex = 10;
            this.label4.Text = "Brand";
            // 
            // MobiBrandTb
            // 
            this.MobiBrandTb.BackColor = System.Drawing.Color.Gainsboro;
            this.MobiBrandTb.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.MobiBrandTb.CustomizableEdges = customizableEdges3;
            this.MobiBrandTb.DefaultText = "";
            this.MobiBrandTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.MobiBrandTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.MobiBrandTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.MobiBrandTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.MobiBrandTb.FillColor = System.Drawing.Color.WhiteSmoke;
            this.MobiBrandTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.MobiBrandTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MobiBrandTb.ForeColor = System.Drawing.Color.Black;
            this.MobiBrandTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.MobiBrandTb.Location = new System.Drawing.Point(160, 167);
            this.MobiBrandTb.Name = "MobiBrandTb";
            this.MobiBrandTb.PasswordChar = '\0';
            this.MobiBrandTb.PlaceholderText = "Enter Brand";
            this.MobiBrandTb.SelectedText = "";
            this.MobiBrandTb.ShadowDecoration.CustomizableEdges = customizableEdges4;
            this.MobiBrandTb.Size = new System.Drawing.Size(111, 38);
            this.MobiBrandTb.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(49, 239);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 28);
            this.label5.TabIndex = 12;
            this.label5.Text = "Modele";
            // 
            // MobiModeleTb
            // 
            this.MobiModeleTb.BackColor = System.Drawing.Color.Gainsboro;
            this.MobiModeleTb.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.MobiModeleTb.CustomizableEdges = customizableEdges5;
            this.MobiModeleTb.DefaultText = "";
            this.MobiModeleTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.MobiModeleTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.MobiModeleTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.MobiModeleTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.MobiModeleTb.FillColor = System.Drawing.Color.WhiteSmoke;
            this.MobiModeleTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.MobiModeleTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MobiModeleTb.ForeColor = System.Drawing.Color.Black;
            this.MobiModeleTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.MobiModeleTb.Location = new System.Drawing.Point(160, 229);
            this.MobiModeleTb.Name = "MobiModeleTb";
            this.MobiModeleTb.PasswordChar = '\0';
            this.MobiModeleTb.PlaceholderText = "Enter Modele";
            this.MobiModeleTb.SelectedText = "";
            this.MobiModeleTb.ShadowDecoration.CustomizableEdges = customizableEdges6;
            this.MobiModeleTb.Size = new System.Drawing.Size(111, 38);
            this.MobiModeleTb.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(309, 177);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 28);
            this.label6.TabIndex = 14;
            this.label6.Text = "Price";
            // 
            // MobiPriceTb
            // 
            this.MobiPriceTb.BackColor = System.Drawing.Color.Gainsboro;
            this.MobiPriceTb.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.MobiPriceTb.CustomizableEdges = customizableEdges7;
            this.MobiPriceTb.DefaultText = "";
            this.MobiPriceTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.MobiPriceTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.MobiPriceTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.MobiPriceTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.MobiPriceTb.FillColor = System.Drawing.Color.WhiteSmoke;
            this.MobiPriceTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.MobiPriceTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MobiPriceTb.ForeColor = System.Drawing.Color.Black;
            this.MobiPriceTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.MobiPriceTb.Location = new System.Drawing.Point(456, 167);
            this.MobiPriceTb.Name = "MobiPriceTb";
            this.MobiPriceTb.PasswordChar = '\0';
            this.MobiPriceTb.PlaceholderText = "Enter Price";
            this.MobiPriceTb.SelectedText = "";
            this.MobiPriceTb.ShadowDecoration.CustomizableEdges = customizableEdges8;
            this.MobiPriceTb.Size = new System.Drawing.Size(142, 38);
            this.MobiPriceTb.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(309, 119);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 28);
            this.label7.TabIndex = 16;
            this.label7.Text = "Stock";
            // 
            // MobiStockTb
            // 
            this.MobiStockTb.BackColor = System.Drawing.Color.Gainsboro;
            this.MobiStockTb.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.MobiStockTb.CustomizableEdges = customizableEdges9;
            this.MobiStockTb.DefaultText = "";
            this.MobiStockTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.MobiStockTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.MobiStockTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.MobiStockTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.MobiStockTb.FillColor = System.Drawing.Color.WhiteSmoke;
            this.MobiStockTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.MobiStockTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MobiStockTb.ForeColor = System.Drawing.Color.Black;
            this.MobiStockTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.MobiStockTb.Location = new System.Drawing.Point(456, 109);
            this.MobiStockTb.Name = "MobiStockTb";
            this.MobiStockTb.PasswordChar = '\0';
            this.MobiStockTb.PlaceholderText = "Enter Stock";
            this.MobiStockTb.SelectedText = "";
            this.MobiStockTb.ShadowDecoration.CustomizableEdges = customizableEdges10;
            this.MobiStockTb.Size = new System.Drawing.Size(142, 38);
            this.MobiStockTb.TabIndex = 17;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(646, 119);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 28);
            this.label8.TabIndex = 18;
            this.label8.Text = "RAM in GB";
            // 
            // ramcb
            // 
            this.ramcb.FormattingEnabled = true;
            this.ramcb.Items.AddRange(new object[] {
            "2",
            "4",
            "6",
            "8",
            "12"});
            this.ramcb.Location = new System.Drawing.Point(790, 109);
            this.ramcb.Name = "ramcb";
            this.ramcb.Size = new System.Drawing.Size(105, 28);
            this.ramcb.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(646, 177);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 28);
            this.label9.TabIndex = 20;
            this.label9.Text = "ROM in GB";
            // 
            // romcb
            // 
            this.romcb.FormattingEnabled = true;
            this.romcb.Items.AddRange(new object[] {
            "2",
            "4",
            "6",
            "8",
            "12"});
            this.romcb.Location = new System.Drawing.Point(790, 177);
            this.romcb.Name = "romcb";
            this.romcb.Size = new System.Drawing.Size(105, 28);
            this.romcb.TabIndex = 21;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(309, 239);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(136, 28);
            this.label10.TabIndex = 22;
            this.label10.Text = "Camera in MP";
            // 
            // CamTb
            // 
            this.CamTb.BackColor = System.Drawing.Color.Gainsboro;
            this.CamTb.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.CamTb.CustomizableEdges = customizableEdges11;
            this.CamTb.DefaultText = "";
            this.CamTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.CamTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.CamTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.CamTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.CamTb.FillColor = System.Drawing.Color.WhiteSmoke;
            this.CamTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CamTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CamTb.ForeColor = System.Drawing.Color.Black;
            this.CamTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CamTb.Location = new System.Drawing.Point(456, 229);
            this.CamTb.Name = "CamTb";
            this.CamTb.PasswordChar = '\0';
            this.CamTb.PlaceholderText = "Enter Camera MP";
            this.CamTb.SelectedText = "";
            this.CamTb.ShadowDecoration.CustomizableEdges = customizableEdges12;
            this.CamTb.Size = new System.Drawing.Size(142, 38);
            this.CamTb.TabIndex = 23;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.IndianRed;
            this.panel1.Controls.Add(this.label11);
            this.panel1.Location = new System.Drawing.Point(0, 329);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(950, 30);
            this.panel1.TabIndex = 24;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(384, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(145, 28);
            this.label11.TabIndex = 25;
            this.label11.Text = "Mobiles Stock";
            // 
            // MAddbtn
            // 
            this.MAddbtn.BorderRadius = 14;
            this.MAddbtn.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            this.MAddbtn.CustomizableEdges = customizableEdges13;
            this.MAddbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.MAddbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.MAddbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.MAddbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.MAddbtn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MAddbtn.ForeColor = System.Drawing.Color.Black;
            this.MAddbtn.HoverState.BorderColor = System.Drawing.Color.Black;
            this.MAddbtn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.MAddbtn.HoverState.ForeColor = System.Drawing.Color.Black;
            this.MAddbtn.Location = new System.Drawing.Point(176, 286);
            this.MAddbtn.Name = "MAddbtn";
            this.MAddbtn.ShadowDecoration.CustomizableEdges = customizableEdges14;
            this.MAddbtn.Size = new System.Drawing.Size(110, 37);
            this.MAddbtn.TabIndex = 25;
            this.MAddbtn.Text = "Add";
            this.MAddbtn.Click += new System.EventHandler(this.MAddbtn_Click);
            // 
            // MobileUpdatebtn
            // 
            this.MobileUpdatebtn.BorderRadius = 14;
            this.MobileUpdatebtn.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            this.MobileUpdatebtn.CustomizableEdges = customizableEdges15;
            this.MobileUpdatebtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.MobileUpdatebtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.MobileUpdatebtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.MobileUpdatebtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.MobileUpdatebtn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MobileUpdatebtn.ForeColor = System.Drawing.Color.Black;
            this.MobileUpdatebtn.HoverState.BorderColor = System.Drawing.Color.Black;
            this.MobileUpdatebtn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.MobileUpdatebtn.HoverState.ForeColor = System.Drawing.Color.Black;
            this.MobileUpdatebtn.Location = new System.Drawing.Point(326, 286);
            this.MobileUpdatebtn.Name = "MobileUpdatebtn";
            this.MobileUpdatebtn.ShadowDecoration.CustomizableEdges = customizableEdges16;
            this.MobileUpdatebtn.Size = new System.Drawing.Size(110, 37);
            this.MobileUpdatebtn.TabIndex = 26;
            this.MobileUpdatebtn.Text = "Update";
            this.MobileUpdatebtn.Click += new System.EventHandler(this.MobileUpdatebtn_Click);
            // 
            // MobileDeletebtn
            // 
            this.MobileDeletebtn.BorderRadius = 14;
            this.MobileDeletebtn.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            this.MobileDeletebtn.CustomizableEdges = customizableEdges17;
            this.MobileDeletebtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.MobileDeletebtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.MobileDeletebtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.MobileDeletebtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.MobileDeletebtn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MobileDeletebtn.ForeColor = System.Drawing.Color.Black;
            this.MobileDeletebtn.HoverState.BorderColor = System.Drawing.Color.Black;
            this.MobileDeletebtn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.MobileDeletebtn.HoverState.ForeColor = System.Drawing.Color.Black;
            this.MobileDeletebtn.Location = new System.Drawing.Point(474, 286);
            this.MobileDeletebtn.Name = "MobileDeletebtn";
            this.MobileDeletebtn.ShadowDecoration.CustomizableEdges = customizableEdges18;
            this.MobileDeletebtn.Size = new System.Drawing.Size(110, 37);
            this.MobileDeletebtn.TabIndex = 27;
            this.MobileDeletebtn.Text = "Delete";
            this.MobileDeletebtn.Click += new System.EventHandler(this.MobileDeletebtn_Click);
            // 
            // MobileClearbtn
            // 
            this.MobileClearbtn.BorderRadius = 14;
            this.MobileClearbtn.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            this.MobileClearbtn.CustomizableEdges = customizableEdges19;
            this.MobileClearbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.MobileClearbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.MobileClearbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.MobileClearbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.MobileClearbtn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MobileClearbtn.ForeColor = System.Drawing.Color.Black;
            this.MobileClearbtn.HoverState.BorderColor = System.Drawing.Color.Black;
            this.MobileClearbtn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.MobileClearbtn.HoverState.ForeColor = System.Drawing.Color.Black;
            this.MobileClearbtn.Location = new System.Drawing.Point(624, 286);
            this.MobileClearbtn.Name = "MobileClearbtn";
            this.MobileClearbtn.ShadowDecoration.CustomizableEdges = customizableEdges20;
            this.MobileClearbtn.Size = new System.Drawing.Size(110, 37);
            this.MobileClearbtn.TabIndex = 28;
            this.MobileClearbtn.Text = "Clear";
            this.MobileClearbtn.Click += new System.EventHandler(this.MobileClearbtn_Click);
            // 
            // MobileDGV
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.MobileDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.MobileDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.MobileDGV.ColumnHeadersHeight = 25;
            this.MobileDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.MobileDGV.DefaultCellStyle = dataGridViewCellStyle3;
            this.MobileDGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.MobileDGV.Location = new System.Drawing.Point(0, 360);
            this.MobileDGV.Name = "MobileDGV";
            this.MobileDGV.RowHeadersVisible = false;
            this.MobileDGV.RowHeadersWidth = 51;
            this.MobileDGV.Size = new System.Drawing.Size(950, 287);
            this.MobileDGV.TabIndex = 29;
            this.MobileDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.MobileDGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.MobileDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.MobileDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.MobileDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.MobileDGV.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.MobileDGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.MobileDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.SystemColors.Highlight;
            this.MobileDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.MobileDGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MobileDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.MobileDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.MobileDGV.ThemeStyle.HeaderStyle.Height = 25;
            this.MobileDGV.ThemeStyle.ReadOnly = false;
            this.MobileDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.MobileDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.MobileDGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MobileDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.MobileDGV.ThemeStyle.RowsStyle.Height = 22;
            this.MobileDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.MobileDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.MobileDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.MobileDGV_CellContentClick);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(926, -2);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(24, 28);
            this.label12.TabIndex = 30;
            this.label12.Text = "X";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(309, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(342, 28);
            this.label13.TabIndex = 3;
            this.label13.Text = "Heaven Mobile Management System";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(373, 48);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(211, 28);
            this.label14.TabIndex = 4;
            this.label14.Text = "Manage Mobile Stock";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(49, 119);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(37, 28);
            this.label15.TabIndex = 8;
            this.label15.Text = "ID";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label16.Location = new System.Drawing.Point(49, 177);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(67, 28);
            this.label16.TabIndex = 10;
            this.label16.Text = "Brand";
            // 
            // BackMBbtn
            // 
            this.BackMBbtn.BorderRadius = 16;
            this.BackMBbtn.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            this.BackMBbtn.CustomizableEdges = customizableEdges21;
            this.BackMBbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BackMBbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BackMBbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BackMBbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BackMBbtn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BackMBbtn.ForeColor = System.Drawing.Color.Black;
            this.BackMBbtn.HoverState.BorderColor = System.Drawing.Color.Black;
            this.BackMBbtn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.BackMBbtn.HoverState.ForeColor = System.Drawing.Color.Black;
            this.BackMBbtn.Location = new System.Drawing.Point(0, 0);
            this.BackMBbtn.Name = "BackMBbtn";
            this.BackMBbtn.ShadowDecoration.CustomizableEdges = customizableEdges22;
            this.BackMBbtn.Size = new System.Drawing.Size(110, 37);
            this.BackMBbtn.TabIndex = 31;
            this.BackMBbtn.Text = "Back";
            this.BackMBbtn.Click += new System.EventHandler(this.BackMBbtn_Click);
            // 
            // Mobile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(949, 647);
            this.Controls.Add(this.BackMBbtn);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.MobileDGV);
            this.Controls.Add(this.MobileClearbtn);
            this.Controls.Add(this.MobileDeletebtn);
            this.Controls.Add(this.MobileUpdatebtn);
            this.Controls.Add(this.MAddbtn);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.CamTb);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.romcb);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.ramcb);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.MobiStockTb);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.MobiPriceTb);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.MobiModeleTb);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.MobiBrandTb);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.MobileIDTb);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Mobile";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mobile";
            this.Load += new System.EventHandler(this.Mobile_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MobileDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Guna.UI2.WinForms.Guna2TextBox MobileIDTb;
        private Label label4;
        private Guna.UI2.WinForms.Guna2TextBox MobiBrandTb;
        private Label label5;
        private Guna.UI2.WinForms.Guna2TextBox MobiModeleTb;
        private Label label6;
        private Guna.UI2.WinForms.Guna2TextBox MobiPriceTb;
        private Label label7;
        private Guna.UI2.WinForms.Guna2TextBox MobiStockTb;
        private Label label8;
        private ComboBox ramcb;
        private Label label9;
        private ComboBox romcb;
        private Label label10;
        private Guna.UI2.WinForms.Guna2TextBox CamTb;
        private Panel panel1;
        private Label label11;
        private Guna.UI2.WinForms.Guna2Button MAddbtn;
        private Guna.UI2.WinForms.Guna2Button MobileUpdatebtn;
        private Guna.UI2.WinForms.Guna2Button MobileDeletebtn;
        private Guna.UI2.WinForms.Guna2Button MobileClearbtn;
        private Guna.UI2.WinForms.Guna2DataGridView MobileDGV;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Guna.UI2.WinForms.Guna2Button BackMBbtn;
    }
}