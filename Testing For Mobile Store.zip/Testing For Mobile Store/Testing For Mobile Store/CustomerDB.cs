﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Testing_For_Mobile_Store
{
    public partial class CustomerDB : Form
    {
        private Login login;
        public CustomerDB(Login login)
        {
            InitializeComponent();
            this.login = login;
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\jonat\OneDrive\Documents\HeavenDB.mdf;Integrated Security=True;Connect Timeout=30");

        private void label12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void populate()
        {
            Con.Open();
            String query = "select * from BillTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            CustomerDBDGV.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void Backbtn_Click(object sender, EventArgs e)
        {
            Home home = new Home(login);
            home.Show();
            this.Hide();
        }

        private void CustomerDB_Load(object sender, EventArgs e)
        {
            populate();
        }
    }
}
