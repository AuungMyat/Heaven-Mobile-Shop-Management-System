﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Testing_For_Mobile_Store
{
    public partial class Accessories : Form
    {
        private Login login;
        public Accessories(Login login)
        {
            InitializeComponent();
            this.login = login;
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\jonat\OneDrive\Documents\HeavenDB.mdf;Integrated Security=True;Connect Timeout=30");
        private void populate()
        {
            Con.Open();
            String query = "select * from AccessoriesTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            AccessoriesDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void AAddbtn_Click(object sender, EventArgs e)
        {
            if (AccessoriesIDTb.Text == "" || ABrandTb.Text == "" || AModelTb.Text == "" || APriceTb.Text == "" || AStockTb.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    String sql = "insert into AccessoriesTbl values(" + AccessoriesIDTb.Text + ",'" + ABrandTb.Text + "','" + AModelTb.Text + "'," + APriceTb.Text + "," + AStockTb.Text + ")";
                    SqlCommand cmd = new SqlCommand(sql, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Accessorie Added Successfully");
                    Con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void Accessories_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AClearbtn_Click(object sender, EventArgs e)
        {
            AccessoriesIDTb.Text = "";
            ABrandTb.Text = "";
            AModelTb.Text = "";
            AStockTb.Text = "";
            APriceTb.Text = "";
        }

        private void AccessoriesDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            AccessoriesIDTb.Text = AccessoriesDGV.SelectedRows[0].Cells[0].Value.ToString();
            ABrandTb.Text = AccessoriesDGV.SelectedRows[0].Cells[1].Value.ToString();
            AModelTb.Text = AccessoriesDGV.SelectedRows[0].Cells[2].Value.ToString();
            AStockTb.Text = AccessoriesDGV.SelectedRows[0].Cells[3].Value.ToString();
            APriceTb.Text = AccessoriesDGV.SelectedRows[0].Cells[4].Value.ToString();
        }

        private void ADeletebtn_Click(object sender, EventArgs e)
        {
            if (AccessoriesIDTb.Text == "")
            {
                MessageBox.Show("Enter the Accessorie id to be deleted");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "delete from AccessoriesTbl where AccessoriesID=" + AccessoriesIDTb.Text + "";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Accessorie Deleted");
                    Con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void AUpdatebtn_Click(object sender, EventArgs e)
        {
            if (AccessoriesIDTb.Text == "" || ABrandTb.Text == "" || AModelTb.Text == "" || APriceTb.Text == "" || AStockTb.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    String sql = "update AccessoriesTbl set ABrand='" + ABrandTb.Text + "', AModel='" + AModelTb.Text + "',APrice=" + APriceTb.Text + ",AStock=" + AStockTb.Text +"where AccessoriesID="+AccessoriesIDTb.Text+";";
                    SqlCommand cmd = new SqlCommand(sql, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Accessorie Updated Successfully");
                    Con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void BackAccbtn_Click(object sender, EventArgs e)
        {
            Home home = new Home(login);
            home.Show();
            this.Hide();
        }
    }
}
