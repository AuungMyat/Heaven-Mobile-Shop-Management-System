﻿namespace Testing_For_Mobile_Store
{
    partial class Accessories
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            this.AStockTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.APriceTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.AModelTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ABrandTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.AccessoriesIDTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.AClearbtn = new Guna.UI2.WinForms.Guna2Button();
            this.ADeletebtn = new Guna.UI2.WinForms.Guna2Button();
            this.AUpdatebtn = new Guna.UI2.WinForms.Guna2Button();
            this.AAddbtn = new Guna.UI2.WinForms.Guna2Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.AccessoriesDGV = new Guna.UI2.WinForms.Guna2DataGridView();
            this.BackAccbtn = new Guna.UI2.WinForms.Guna2Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AccessoriesDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // AStockTb
            // 
            this.AStockTb.BackColor = System.Drawing.Color.Gainsboro;
            this.AStockTb.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.AStockTb.CustomizableEdges = customizableEdges1;
            this.AStockTb.DefaultText = "";
            this.AStockTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.AStockTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.AStockTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.AStockTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.AStockTb.FillColor = System.Drawing.Color.WhiteSmoke;
            this.AStockTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.AStockTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AStockTb.ForeColor = System.Drawing.Color.Black;
            this.AStockTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.AStockTb.Location = new System.Drawing.Point(449, 109);
            this.AStockTb.Name = "AStockTb";
            this.AStockTb.PasswordChar = '\0';
            this.AStockTb.PlaceholderText = "Enter Stock";
            this.AStockTb.SelectedText = "";
            this.AStockTb.ShadowDecoration.CustomizableEdges = customizableEdges2;
            this.AStockTb.Size = new System.Drawing.Size(142, 38);
            this.AStockTb.TabIndex = 29;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(302, 119);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 28);
            this.label7.TabIndex = 28;
            this.label7.Text = "Stock";
            // 
            // APriceTb
            // 
            this.APriceTb.BackColor = System.Drawing.Color.Gainsboro;
            this.APriceTb.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.APriceTb.CustomizableEdges = customizableEdges3;
            this.APriceTb.DefaultText = "";
            this.APriceTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.APriceTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.APriceTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.APriceTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.APriceTb.FillColor = System.Drawing.Color.WhiteSmoke;
            this.APriceTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.APriceTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.APriceTb.ForeColor = System.Drawing.Color.Black;
            this.APriceTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.APriceTb.Location = new System.Drawing.Point(449, 167);
            this.APriceTb.Name = "APriceTb";
            this.APriceTb.PasswordChar = '\0';
            this.APriceTb.PlaceholderText = "Enter Price";
            this.APriceTb.SelectedText = "";
            this.APriceTb.ShadowDecoration.CustomizableEdges = customizableEdges4;
            this.APriceTb.Size = new System.Drawing.Size(142, 38);
            this.APriceTb.TabIndex = 27;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(302, 177);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 28);
            this.label6.TabIndex = 26;
            this.label6.Text = "Price";
            // 
            // AModelTb
            // 
            this.AModelTb.BackColor = System.Drawing.Color.Gainsboro;
            this.AModelTb.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.AModelTb.CustomizableEdges = customizableEdges5;
            this.AModelTb.DefaultText = "";
            this.AModelTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.AModelTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.AModelTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.AModelTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.AModelTb.FillColor = System.Drawing.Color.WhiteSmoke;
            this.AModelTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.AModelTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AModelTb.ForeColor = System.Drawing.Color.Black;
            this.AModelTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.AModelTb.Location = new System.Drawing.Point(153, 229);
            this.AModelTb.Name = "AModelTb";
            this.AModelTb.PasswordChar = '\0';
            this.AModelTb.PlaceholderText = "Enter Modele";
            this.AModelTb.SelectedText = "";
            this.AModelTb.ShadowDecoration.CustomizableEdges = customizableEdges6;
            this.AModelTb.Size = new System.Drawing.Size(111, 38);
            this.AModelTb.TabIndex = 25;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(42, 239);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 28);
            this.label5.TabIndex = 24;
            this.label5.Text = "Modele";
            // 
            // ABrandTb
            // 
            this.ABrandTb.BackColor = System.Drawing.Color.Gainsboro;
            this.ABrandTb.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ABrandTb.CustomizableEdges = customizableEdges7;
            this.ABrandTb.DefaultText = "";
            this.ABrandTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.ABrandTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.ABrandTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ABrandTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ABrandTb.FillColor = System.Drawing.Color.WhiteSmoke;
            this.ABrandTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ABrandTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ABrandTb.ForeColor = System.Drawing.Color.Black;
            this.ABrandTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ABrandTb.Location = new System.Drawing.Point(153, 167);
            this.ABrandTb.Name = "ABrandTb";
            this.ABrandTb.PasswordChar = '\0';
            this.ABrandTb.PlaceholderText = "Enter Brand";
            this.ABrandTb.SelectedText = "";
            this.ABrandTb.ShadowDecoration.CustomizableEdges = customizableEdges8;
            this.ABrandTb.Size = new System.Drawing.Size(111, 38);
            this.ABrandTb.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(42, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 28);
            this.label4.TabIndex = 22;
            this.label4.Text = "Brand";
            // 
            // AccessoriesIDTb
            // 
            this.AccessoriesIDTb.BackColor = System.Drawing.Color.Gainsboro;
            this.AccessoriesIDTb.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.AccessoriesIDTb.CustomizableEdges = customizableEdges9;
            this.AccessoriesIDTb.DefaultText = "";
            this.AccessoriesIDTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.AccessoriesIDTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.AccessoriesIDTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.AccessoriesIDTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.AccessoriesIDTb.FillColor = System.Drawing.Color.WhiteSmoke;
            this.AccessoriesIDTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.AccessoriesIDTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AccessoriesIDTb.ForeColor = System.Drawing.Color.Black;
            this.AccessoriesIDTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.AccessoriesIDTb.Location = new System.Drawing.Point(153, 109);
            this.AccessoriesIDTb.Name = "AccessoriesIDTb";
            this.AccessoriesIDTb.PasswordChar = '\0';
            this.AccessoriesIDTb.PlaceholderText = "Enter ID";
            this.AccessoriesIDTb.SelectedText = "";
            this.AccessoriesIDTb.ShadowDecoration.CustomizableEdges = customizableEdges10;
            this.AccessoriesIDTb.Size = new System.Drawing.Size(111, 38);
            this.AccessoriesIDTb.TabIndex = 21;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(42, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 28);
            this.label3.TabIndex = 20;
            this.label3.Text = "ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(341, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(261, 28);
            this.label2.TabIndex = 19;
            this.label2.Text = "Manage Accessories Stock";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(302, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(342, 28);
            this.label1.TabIndex = 18;
            this.label1.Text = "Heaven Mobile Management System";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(928, -1);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(24, 28);
            this.label12.TabIndex = 36;
            this.label12.Text = "X";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // AClearbtn
            // 
            this.AClearbtn.BorderRadius = 14;
            this.AClearbtn.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            this.AClearbtn.CustomizableEdges = customizableEdges11;
            this.AClearbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.AClearbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.AClearbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.AClearbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.AClearbtn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AClearbtn.ForeColor = System.Drawing.Color.Black;
            this.AClearbtn.HoverState.BorderColor = System.Drawing.Color.Black;
            this.AClearbtn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.AClearbtn.HoverState.ForeColor = System.Drawing.Color.Black;
            this.AClearbtn.Location = new System.Drawing.Point(800, 177);
            this.AClearbtn.Name = "AClearbtn";
            this.AClearbtn.ShadowDecoration.CustomizableEdges = customizableEdges12;
            this.AClearbtn.Size = new System.Drawing.Size(110, 37);
            this.AClearbtn.TabIndex = 35;
            this.AClearbtn.Text = "Clear";
            this.AClearbtn.Click += new System.EventHandler(this.AClearbtn_Click);
            // 
            // ADeletebtn
            // 
            this.ADeletebtn.BorderRadius = 14;
            this.ADeletebtn.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            this.ADeletebtn.CustomizableEdges = customizableEdges13;
            this.ADeletebtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.ADeletebtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.ADeletebtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.ADeletebtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.ADeletebtn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ADeletebtn.ForeColor = System.Drawing.Color.Black;
            this.ADeletebtn.HoverState.BorderColor = System.Drawing.Color.Black;
            this.ADeletebtn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ADeletebtn.HoverState.ForeColor = System.Drawing.Color.Black;
            this.ADeletebtn.Location = new System.Drawing.Point(646, 177);
            this.ADeletebtn.Name = "ADeletebtn";
            this.ADeletebtn.ShadowDecoration.CustomizableEdges = customizableEdges14;
            this.ADeletebtn.Size = new System.Drawing.Size(110, 37);
            this.ADeletebtn.TabIndex = 34;
            this.ADeletebtn.Text = "Delete";
            this.ADeletebtn.Click += new System.EventHandler(this.ADeletebtn_Click);
            // 
            // AUpdatebtn
            // 
            this.AUpdatebtn.BorderRadius = 14;
            this.AUpdatebtn.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            this.AUpdatebtn.CustomizableEdges = customizableEdges15;
            this.AUpdatebtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.AUpdatebtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.AUpdatebtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.AUpdatebtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.AUpdatebtn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AUpdatebtn.ForeColor = System.Drawing.Color.Black;
            this.AUpdatebtn.HoverState.BorderColor = System.Drawing.Color.Black;
            this.AUpdatebtn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.AUpdatebtn.HoverState.ForeColor = System.Drawing.Color.Black;
            this.AUpdatebtn.Location = new System.Drawing.Point(800, 110);
            this.AUpdatebtn.Name = "AUpdatebtn";
            this.AUpdatebtn.ShadowDecoration.CustomizableEdges = customizableEdges16;
            this.AUpdatebtn.Size = new System.Drawing.Size(110, 37);
            this.AUpdatebtn.TabIndex = 33;
            this.AUpdatebtn.Text = "Update";
            this.AUpdatebtn.Click += new System.EventHandler(this.AUpdatebtn_Click);
            // 
            // AAddbtn
            // 
            this.AAddbtn.BorderRadius = 14;
            this.AAddbtn.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            this.AAddbtn.CustomizableEdges = customizableEdges17;
            this.AAddbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.AAddbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.AAddbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.AAddbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.AAddbtn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AAddbtn.ForeColor = System.Drawing.Color.Black;
            this.AAddbtn.HoverState.BorderColor = System.Drawing.Color.Black;
            this.AAddbtn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.AAddbtn.HoverState.ForeColor = System.Drawing.Color.Black;
            this.AAddbtn.Location = new System.Drawing.Point(646, 110);
            this.AAddbtn.Name = "AAddbtn";
            this.AAddbtn.ShadowDecoration.CustomizableEdges = customizableEdges18;
            this.AAddbtn.Size = new System.Drawing.Size(110, 37);
            this.AAddbtn.TabIndex = 32;
            this.AAddbtn.Text = "Add";
            this.AAddbtn.Click += new System.EventHandler(this.AAddbtn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.IndianRed;
            this.panel1.Controls.Add(this.label11);
            this.panel1.Location = new System.Drawing.Point(0, 280);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(952, 30);
            this.panel1.TabIndex = 31;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(366, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(185, 28);
            this.label11.TabIndex = 25;
            this.label11.Text = "Accessories Stock";
            // 
            // AccessoriesDGV
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.AccessoriesDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.AccessoriesDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.AccessoriesDGV.ColumnHeadersHeight = 25;
            this.AccessoriesDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.AccessoriesDGV.DefaultCellStyle = dataGridViewCellStyle3;
            this.AccessoriesDGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.AccessoriesDGV.Location = new System.Drawing.Point(0, 311);
            this.AccessoriesDGV.Name = "AccessoriesDGV";
            this.AccessoriesDGV.RowHeadersVisible = false;
            this.AccessoriesDGV.RowHeadersWidth = 51;
            this.AccessoriesDGV.RowTemplate.Height = 29;
            this.AccessoriesDGV.Size = new System.Drawing.Size(950, 336);
            this.AccessoriesDGV.TabIndex = 29;
            this.AccessoriesDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.AccessoriesDGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.AccessoriesDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.AccessoriesDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.AccessoriesDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.AccessoriesDGV.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.AccessoriesDGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.AccessoriesDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.AccessoriesDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.AccessoriesDGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AccessoriesDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.AccessoriesDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.AccessoriesDGV.ThemeStyle.HeaderStyle.Height = 25;
            this.AccessoriesDGV.ThemeStyle.ReadOnly = false;
            this.AccessoriesDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.AccessoriesDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.AccessoriesDGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AccessoriesDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.AccessoriesDGV.ThemeStyle.RowsStyle.Height = 29;
            this.AccessoriesDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.AccessoriesDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.AccessoriesDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.AccessoriesDGV_CellContentClick);
            // 
            // BackAccbtn
            // 
            this.BackAccbtn.BorderRadius = 16;
            this.BackAccbtn.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            this.BackAccbtn.CustomizableEdges = customizableEdges19;
            this.BackAccbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BackAccbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BackAccbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BackAccbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BackAccbtn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BackAccbtn.ForeColor = System.Drawing.Color.Black;
            this.BackAccbtn.HoverState.BorderColor = System.Drawing.Color.Black;
            this.BackAccbtn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.BackAccbtn.HoverState.ForeColor = System.Drawing.Color.Black;
            this.BackAccbtn.Location = new System.Drawing.Point(0, 0);
            this.BackAccbtn.Name = "BackAccbtn";
            this.BackAccbtn.ShadowDecoration.CustomizableEdges = customizableEdges20;
            this.BackAccbtn.Size = new System.Drawing.Size(110, 37);
            this.BackAccbtn.TabIndex = 37;
            this.BackAccbtn.Text = "Back";
            this.BackAccbtn.Click += new System.EventHandler(this.BackAccbtn_Click);
            // 
            // Accessories
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(949, 647);
            this.Controls.Add(this.BackAccbtn);
            this.Controls.Add(this.AccessoriesDGV);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.AClearbtn);
            this.Controls.Add(this.ADeletebtn);
            this.Controls.Add(this.AUpdatebtn);
            this.Controls.Add(this.AAddbtn);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.AStockTb);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.APriceTb);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.AModelTb);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ABrandTb);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.AccessoriesIDTb);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Accessories";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Accessories";
            this.Load += new System.EventHandler(this.Accessories_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AccessoriesDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox AStockTb;
        private Label label7;
        private Guna.UI2.WinForms.Guna2TextBox APriceTb;
        private Label label6;
        private Guna.UI2.WinForms.Guna2TextBox AModelTb;
        private Label label5;
        private Guna.UI2.WinForms.Guna2TextBox ABrandTb;
        private Label label4;
        private Guna.UI2.WinForms.Guna2TextBox AccessoriesIDTb;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label12;
        private Guna.UI2.WinForms.Guna2Button AClearbtn;
        private Guna.UI2.WinForms.Guna2Button ADeletebtn;
        private Guna.UI2.WinForms.Guna2Button AUpdatebtn;
        private Guna.UI2.WinForms.Guna2Button AAddbtn;
        private Panel panel1;
        private Label label11;
        private Guna.UI2.WinForms.Guna2DataGridView AccessoriesDGV;
        private Guna.UI2.WinForms.Guna2Button BackAccbtn;
    }
}