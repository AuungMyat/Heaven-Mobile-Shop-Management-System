﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Testing_For_Mobile_Store
{
    public partial class Mobile : Form
    {
        private Login login;
        public Mobile(Login login)
        {
            InitializeComponent();
            this.login = login;
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\jonat\OneDrive\Documents\HeavenDB.mdf;Integrated Security=True;Connect Timeout=30");


        private void label12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void populate()
        {
            Con.Open();
            String query = "select * from MobileTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            MobileDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void MAddbtn_Click(object sender, EventArgs e)
        {
            if(MobileIDTb.Text == "" || MobiBrandTb.Text == "" || MobiModeleTb.Text == "" || MobiPriceTb.Text == "" || MobiStockTb.Text == "" || CamTb.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    String sql = "insert into MobileTbl values("+MobileIDTb.Text+",'"+MobiBrandTb.Text+"','"+MobiModeleTb.Text+"',"+MobiPriceTb.Text+","+MobiStockTb.Text+","+ramcb.SelectedItem.ToString()+","+romcb.SelectedItem.ToString()+","+CamTb.Text+")";
                    SqlCommand cmd = new SqlCommand(sql, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Mobile Added Successfully");
                    Con.Close();
                    populate();
                }catch(Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void Mobile_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void MobileDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            MobileIDTb.Text = MobileDGV.SelectedRows[0].Cells[0].Value.ToString();
            MobiBrandTb.Text = MobileDGV.SelectedRows[0].Cells[1].Value.ToString();
            MobiModeleTb.Text = MobileDGV.SelectedRows[0].Cells[2].Value.ToString();
            MobiPriceTb.Text = MobileDGV.SelectedRows[0].Cells[3].Value.ToString();
            MobiStockTb.Text = MobileDGV.SelectedRows[0].Cells[4].Value.ToString();
            ramcb.SelectedItem = MobileDGV.SelectedRows[0].Cells[5].Value.ToString();
            romcb.SelectedItem = MobileDGV.SelectedRows[0].Cells[6].Value.ToString();
            CamTb.Text = MobileDGV.SelectedRows[0].Cells[7].Value.ToString();
        }

        private void MobileClearbtn_Click(object sender, EventArgs e)
        {
            MobileIDTb.Text = "";
            MobiBrandTb.Text = "";
            MobiModeleTb.Text = "";
            MobiPriceTb.Text = "";
            MobiStockTb.Text = "";
            CamTb.Text = "";
        }

        private void MobileDeletebtn_Click(object sender, EventArgs e)
        {
            if(MobileIDTb.Text == "")
            {
                MessageBox.Show("Enter the mobile id to be deleted");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "delete from MobileTbl where MobileID="+ MobileIDTb.Text +"";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Mobile Deleted");
                    Con.Close();
                    populate();
                }catch(Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void MobileUpdatebtn_Click(object sender, EventArgs e)
        {
            if (MobileIDTb.Text == "" || MobiBrandTb.Text == "" || MobiModeleTb.Text == "" || MobiPriceTb.Text == "" || MobiStockTb.Text == "" || CamTb.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    String sql = "update MobileTbl set MBrand='"+MobiBrandTb.Text+"',MModel='"+MobiModeleTb.Text+"',MPrice='"+MobiPriceTb.Text+"',MStock='"+MobiStockTb.Text+"',MCam='"+CamTb.Text+"',MRam="+ramcb.SelectedItem.ToString()+",MRom="+romcb.SelectedItem.ToString()+"where MobileID="+MobileIDTb.Text+";";
                    SqlCommand cmd = new SqlCommand(sql, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Mobile Updated Successfully");
                    Con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void BackMBbtn_Click(object sender, EventArgs e)
        {
            Home home = new Home(login);
            home.Show();
            this.Hide();
        }
    }
}
