﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Testing_For_Mobile_Store
{
    public partial class Home : Form
    {
        private Login login;
        public Home(Login login)
        {
            InitializeComponent();
            this.login = login;
            UpdateButtonVisibility();
        }

        private void UpdateButtonVisibility()
        {
            if(login != null)
            {
                if(login.UserRole == "Admin")
                {
                    MobileDBbtn.Visible = true;
                    AccessorieDBbtn.Visible = true;
                    SellingDBbtn.Visible= true;
                    CustomerDBbtn.Visible = true;
                }else if(login.UserRole == "Cashier")
                {
                    MobileDBbtn.Visible = false;
                    AccessorieDBbtn.Visible = false;
                    SellingDBbtn.Visible = true;
                    CustomerDBbtn.Visible = true;
                }
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MobileDBbtn_Click(object sender, EventArgs e)
        {
            Mobile mob = new Mobile(login);
            mob.Show();
            this.Hide();
        }

        private void AccessorieDBbtn_Click(object sender, EventArgs e)
        {
            Accessories acc = new Accessories(login);
            acc.Show();
            this.Hide();
        }

        private void SellingDBbtn_Click(object sender, EventArgs e)
        {
            Billing sell = new Billing(login);
            sell.Show();
            this.Hide();
        }

        private void CustomerDBbtn_Click(object sender, EventArgs e)
        {
            CustomerDB CusDB = new CustomerDB(login);
            CusDB.Show();
            this.Hide();
        }
    }
}
