﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Testing_For_Mobile_Store
{
    public partial class Login : Form
    {
        public string UserRole { get; private set; }
        public Login()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            UidTb.Text = "";
            PassTb.Text = "";
        }

        private void Loginbtn_Click(object sender, EventArgs e)
        {
            if(UidTb.Text == "" || PassTb.Text == "")
            {
                MessageBox.Show("Enter User Name and Password");
            }
            else if(UidTb.Text == "Admin" && PassTb.Text == "Admin")
            {
                UserRole = "Admin";
                Home home = new Home(this);
                home.Show();
                this.Hide();
            }else if(UidTb.Text == "Cashier" && PassTb.Text == "Cashier")
            {
                UserRole = "Cashier";
                Home home = new Home(this);
                home.Show();
                this.Hide();

            }
            else
            {
                MessageBox.Show("Wrong User Name or Password");
            }
        }
    }
}
