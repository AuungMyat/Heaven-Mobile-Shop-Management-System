﻿namespace Testing_For_Mobile_Store
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.MobileDBbtn = new Guna.UI2.WinForms.Guna2Button();
            this.AccessorieDBbtn = new Guna.UI2.WinForms.Guna2Button();
            this.SellingDBbtn = new Guna.UI2.WinForms.Guna2Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.CustomerDBbtn = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(170, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(342, 28);
            this.label13.TabIndex = 5;
            this.label13.Text = "Heaven Mobile Management System";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(677, -1);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(24, 28);
            this.label12.TabIndex = 31;
            this.label12.Text = "X";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // MobileDBbtn
            // 
            this.MobileDBbtn.BorderRadius = 14;
            this.MobileDBbtn.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            this.MobileDBbtn.CustomizableEdges = customizableEdges1;
            this.MobileDBbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.MobileDBbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.MobileDBbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.MobileDBbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.MobileDBbtn.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MobileDBbtn.ForeColor = System.Drawing.Color.Black;
            this.MobileDBbtn.HoverState.BorderColor = System.Drawing.Color.Black;
            this.MobileDBbtn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.MobileDBbtn.HoverState.ForeColor = System.Drawing.Color.Black;
            this.MobileDBbtn.Location = new System.Drawing.Point(25, 279);
            this.MobileDBbtn.Name = "MobileDBbtn";
            this.MobileDBbtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            this.MobileDBbtn.Size = new System.Drawing.Size(136, 46);
            this.MobileDBbtn.TabIndex = 32;
            this.MobileDBbtn.Text = "Mobiles";
            this.MobileDBbtn.Click += new System.EventHandler(this.MobileDBbtn_Click);
            // 
            // AccessorieDBbtn
            // 
            this.AccessorieDBbtn.BorderRadius = 14;
            this.AccessorieDBbtn.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            this.AccessorieDBbtn.CustomizableEdges = customizableEdges3;
            this.AccessorieDBbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.AccessorieDBbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.AccessorieDBbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.AccessorieDBbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.AccessorieDBbtn.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AccessorieDBbtn.ForeColor = System.Drawing.Color.Black;
            this.AccessorieDBbtn.HoverState.BorderColor = System.Drawing.Color.Black;
            this.AccessorieDBbtn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.AccessorieDBbtn.HoverState.ForeColor = System.Drawing.Color.Black;
            this.AccessorieDBbtn.Location = new System.Drawing.Point(533, 279);
            this.AccessorieDBbtn.Name = "AccessorieDBbtn";
            this.AccessorieDBbtn.ShadowDecoration.CustomizableEdges = customizableEdges4;
            this.AccessorieDBbtn.Size = new System.Drawing.Size(136, 46);
            this.AccessorieDBbtn.TabIndex = 33;
            this.AccessorieDBbtn.Text = "Accessories";
            this.AccessorieDBbtn.Click += new System.EventHandler(this.AccessorieDBbtn_Click);
            // 
            // SellingDBbtn
            // 
            this.SellingDBbtn.BorderRadius = 14;
            this.SellingDBbtn.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            this.SellingDBbtn.CustomizableEdges = customizableEdges5;
            this.SellingDBbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.SellingDBbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.SellingDBbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.SellingDBbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.SellingDBbtn.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SellingDBbtn.ForeColor = System.Drawing.Color.Black;
            this.SellingDBbtn.HoverState.BorderColor = System.Drawing.Color.Black;
            this.SellingDBbtn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.SellingDBbtn.HoverState.ForeColor = System.Drawing.Color.Black;
            this.SellingDBbtn.Location = new System.Drawing.Point(194, 279);
            this.SellingDBbtn.Name = "SellingDBbtn";
            this.SellingDBbtn.ShadowDecoration.CustomizableEdges = customizableEdges6;
            this.SellingDBbtn.Size = new System.Drawing.Size(136, 46);
            this.SellingDBbtn.TabIndex = 34;
            this.SellingDBbtn.Text = "Selling";
            this.SellingDBbtn.Click += new System.EventHandler(this.SellingDBbtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(170, 65);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(342, 154);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 35;
            this.pictureBox1.TabStop = false;
            // 
            // CustomerDBbtn
            // 
            this.CustomerDBbtn.BorderRadius = 14;
            this.CustomerDBbtn.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            this.CustomerDBbtn.CustomizableEdges = customizableEdges7;
            this.CustomerDBbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.CustomerDBbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.CustomerDBbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.CustomerDBbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.CustomerDBbtn.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CustomerDBbtn.ForeColor = System.Drawing.Color.Black;
            this.CustomerDBbtn.HoverState.BorderColor = System.Drawing.Color.Black;
            this.CustomerDBbtn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.CustomerDBbtn.HoverState.ForeColor = System.Drawing.Color.Black;
            this.CustomerDBbtn.Location = new System.Drawing.Point(367, 279);
            this.CustomerDBbtn.Name = "CustomerDBbtn";
            this.CustomerDBbtn.ShadowDecoration.CustomizableEdges = customizableEdges8;
            this.CustomerDBbtn.Size = new System.Drawing.Size(136, 46);
            this.CustomerDBbtn.TabIndex = 36;
            this.CustomerDBbtn.Text = "CustomerDB";
            this.CustomerDBbtn.Click += new System.EventHandler(this.CustomerDBbtn_Click);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(697, 353);
            this.Controls.Add(this.CustomerDBbtn);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.SellingDBbtn);
            this.Controls.Add(this.AccessorieDBbtn);
            this.Controls.Add(this.MobileDBbtn);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label label13;
        private Label label12;
        private Guna.UI2.WinForms.Guna2Button MobileDBbtn;
        private Guna.UI2.WinForms.Guna2Button AccessorieDBbtn;
        private Guna.UI2.WinForms.Guna2Button SellingDBbtn;
        private PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2Button CustomerDBbtn;
    }
}